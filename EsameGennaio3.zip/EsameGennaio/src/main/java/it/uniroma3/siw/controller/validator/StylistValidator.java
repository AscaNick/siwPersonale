package it.uniroma3.siw.controller.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Stylist;
import it.uniroma3.siw.repository.StylistRepository;

@Component
public class StylistValidator implements Validator{
	
	 @Autowired
	 private StylistRepository stylistRepository;

	@Override
	public boolean supports(Class<?> clazz) {
		return Stylist.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Stylist stylist = (Stylist) target;
        if(stylist.getNome() != null && stylist.getCognome() != null
            && this.stylistRepository.existsByNomeAndCognomeAndEmail(stylist.getNome(), stylist.getCognome(), stylist.getEmail())){
            errors.reject("stylist.duplicate");
        }
		
	}

}