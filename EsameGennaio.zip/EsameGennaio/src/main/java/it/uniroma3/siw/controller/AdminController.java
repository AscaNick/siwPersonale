package it.uniroma3.siw.controller;

import java.util.HashSet;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


import it.uniroma3.siw.controller.validator.DressValidator;
import it.uniroma3.siw.controller.validator.StylistValidator;
import it.uniroma3.siw.model.Dress;
import it.uniroma3.siw.model.Stylist;
import it.uniroma3.siw.repository.DressRepository;
import it.uniroma3.siw.repository.StylistRepository;
import it.uniroma3.siw.service.DressService;
import it.uniroma3.siw.service.UserService;
import jakarta.transaction.Transactional;
import org.springframework.validation.BindingResult;
@Controller
public class AdminController {
	
	 @Autowired
	 private DressRepository dressRepository;
	 @Autowired
	 private StylistRepository stylistRepository;
	 @Autowired
	 private DressValidator dressValidator;
	 @Autowired
	 private StylistValidator stylistValidator;
	 @Autowired
	 private DressService dressService;
	 @Autowired
	 private UserService userService;

	 @GetMapping("/admin/formNewDress")
	 public String newDress(Model model){
		 model.addAttribute("dress",new Dress());
		 return "/admin/formNewDress.html";
	 }
	 
	 @PostMapping("/admin/uploadDress")
	 public String newDress(Model model, @Valid @ModelAttribute("dress") Dress dress, BindingResult bindingResult){       
		 this.dressValidator.validate(dress,bindingResult);
		 if(!bindingResult.hasErrors()){
			 this.dressService.createDress(dress);  
			 model.addAttribute("dress", dress);
			 model.addAttribute("userDetails", this.userService.getUserDetails());
			 return "dress.html";
		 } else {
			 return "/admin/formNewDress.html";
		 }
	 }
	 
	  @GetMapping("/admin/formNewStylist")
	    public String formNewStylist(Model model){
	        model.addAttribute("stylist",new Stylist());
	        return "/admin/formNewStylist.html";
	    }
	  
	  @PostMapping("/admin/stylist")
	    public String newStylist(Model model,@Valid @ModelAttribute("stylist") Stylist stylist, BindingResult bindingResult) {  
	        this.stylistValidator.validate(stylist, bindingResult);
	        if(!bindingResult.hasErrors()){
	            this.stylistRepository.save(stylist);

	            model.addAttribute("stylist", stylist);
	            model.addAttribute("userDetails", this.userService.getUserDetails());
	            return "stylist.html";
	        }
	        else {
	            return "/admin/formNewStylist.html";
	        }
	    }
	  
	  @GetMapping("/admin/manageDresses")
	    public String manageDresses(Model model){
	        model.addAttribute("dresses", this.dressRepository.findAll());
	        return "/admin/manageDresses.html";
	    }
	  

	    @Transactional
	    @GetMapping("/admin/formUpdateDress/{id}")  //update generica, ora ci sono anche nome e prezzo
	    public String formUpdateDress(@PathVariable("id") Long id, Model model){
	        model.addAttribute("dress", this.dressRepository.findById(id).get());
	        return "/admin/formUpdateDress.html";
	    }
	    
	    @Transactional
	    @GetMapping("/admin/editDetailsToDress/{id}")  
	    public String editDetails(@PathVariable("id") Long id,Model model ){

	        model.addAttribute("dress", this.dressRepository.findById(id).get());

	        return "/admin/formUpdateDetailsToDress.html";
	    }
	    
	    
	    @PostMapping("/admin/uploadDress1/{id}")
		 public String editDetailsToDress(@PathVariable("id") Long id, Model model, @Valid @ModelAttribute("dress") Dress dress, BindingResult bindingResult){       
			 this.dressValidator.validate(dress,bindingResult);
			 if(!bindingResult.hasErrors()){
				 model.addAttribute("dress", dress);
				 model.addAttribute("userDetails", this.userService.getUserDetails());
				 this.dressService.editDetailsToDress(dress); 
				 return "/dress.html";
			 } 
//				 return "/index.html";
				 return "/admin/formUpdateDetailsToDress.html";
			 
		 }
	    
	    @Transactional
	    public Set<Stylist> stylistsToAdd(Long dressId){
	        Set<Stylist> stylistsToAdd= new HashSet<Stylist>();
	        stylistsToAdd = this.stylistRepository.getByDressesNotContains(this.dressRepository.findById(dressId).get());
	        return stylistsToAdd;
	    }
	    
	    @Transactional
	    @GetMapping("/admin/updateStylistsOnDress/{id}")  
	    public String updateStylists(@PathVariable("id") Long id,Model model ){

	        Set<Stylist> stylistsToAdd = this.stylistsToAdd(id);
	        model.addAttribute("dress", this.dressRepository.findById(id).get());
	        model.addAttribute("stylistsToAdd", stylistsToAdd);

	        return "/admin/stylistsToAdd.html";
	    }
	    
	    @Transactional
	    @GetMapping("/admin/addStylistToDress/{stylistId}/{dressId}")
	    public String addStylistToDress(@PathVariable("stylistId") Long stylistId, @PathVariable("dressId") Long dressId, Model model){
	        Dress dress = this.dressRepository.findById(dressId).get();
	        this.dressService.setStylistToDress(dress, stylistId);

	        model.addAttribute("dress", dress);
	        model.addAttribute("stylistsToAdd", stylistsToAdd(dressId));

	        return "/admin/stylistsToAdd.html";
	    }
	    
	    @Transactional
	    @GetMapping("/admin/removeStylistFromDress/{stylistId}/{dressId}")
	    public String removeStylistFromDress(@PathVariable("stylistId") Long stylistId, @PathVariable("dressId") Long dressId, Model model){
	        Dress dress = this.dressRepository.findById(dressId).get();

	        this.dressService.removeStylistToDress(dress, stylistId);

	        model.addAttribute("dress", dress);
	        model.addAttribute("stylistsToAdd", stylistsToAdd(dressId));
	        
	        return "/admin/stylistsToAdd.html";
	    }
}