package it.uniroma3.siw.repository;

import java.util.Set;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Dress;
import it.uniroma3.siw.model.Stylist;

public interface StylistRepository extends CrudRepository<Stylist,Long>{

	

	Set<Stylist> getByDressesNotContains(Dress dress);

	boolean existsByNomeAndCognomeAndEmail(String nome, String cognome, String email);

}
